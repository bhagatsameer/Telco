<?php
require_once('php-upgrade.override.php');
require_once('php-upgrade/upgrade.php');
require_once('php-upgrade/ext/gettext.php');
?>
